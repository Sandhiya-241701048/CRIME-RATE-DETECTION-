-- database/schema.sql
-- Run this in Azure SQL Database to set up all tables

CREATE TABLE Users (
    id         INT IDENTITY(1,1) PRIMARY KEY,
    email      VARCHAR(255) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    name       VARCHAR(100),
    role       VARCHAR(20) DEFAULT 'user',
    created_at DATETIME DEFAULT GETDATE()
);

CREATE TABLE Datasets (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    filename    VARCHAR(255) NOT NULL,
    blob_url    VARCHAR(500),
    records     INT DEFAULT 0,
    is_valid    BIT DEFAULT 0,
    uploaded_by VARCHAR(255),
    uploaded_at DATETIME DEFAULT GETDATE()
);

CREATE TABLE CrimeRecords (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    dataset_id  INT FOREIGN KEY REFERENCES Datasets(id) ON DELETE CASCADE,
    location    VARCHAR(255),
    district    VARCHAR(255),
    type        VARCHAR(100),
    date        DATE,
    hour        INT,
    day_of_week INT,
    month       INT,
    count       INT DEFAULT 1
);

CREATE TABLE AnalysisResults (
    id           INT IDENTITY(1,1) PRIMARY KEY,
    location     VARCHAR(255),
    safety_score FLOAT,
    risk_level   VARCHAR(50),
    peak_time    VARCHAR(100),
    peak_day     VARCHAR(50),
    analyzed_at  DATETIME DEFAULT GETDATE()
);

CREATE TABLE Reports (
    id           INT IDENTITY(1,1) PRIMARY KEY,
    title        VARCHAR(255),
    report_type  VARCHAR(50),
    filters      NVARCHAR(MAX),
    content      NVARCHAR(MAX),
    generated_by VARCHAR(255),
    created_at   DATETIME DEFAULT GETDATE()
);

-- Sample data
INSERT INTO Users (email, password, name, role) VALUES
('admin@crime.com', 'hashed_admin123', 'Admin', 'admin'),
('user@crime.com',  'hashed_user123',  'John User', 'user');
