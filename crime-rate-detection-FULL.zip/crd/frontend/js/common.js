// js/common.js — shared helpers for all pages
const API = "http://localhost:5000";

function getSidebarHTML(activePage, role) {
  const isAdmin = role === "admin";
  const name    = localStorage.getItem("userName")  || "User";
  const email   = localStorage.getItem("userEmail") || "";
  const roleStr = localStorage.getItem("userRole")  || "user";

  const adminLinks = isAdmin ? `
    <div class="section-label">Admin</div>
    <a href="admin-dashboard.html" class="${activePage==='admin'?'active':''}">🏠 Admin Dashboard</a>
    <a href="dataset.html"         class="${activePage==='dataset'?'active':''}">📂 Manage Datasets</a>
  ` : "";

  return `
    <div class="brand">🔍 Crime Detection</div>
    <div class="user-info">
      <div class="name">${name}</div>
      <div class="email">${email}</div>
      <span class="role-badge ${roleStr}">${roleStr}</span>
    </div>
    <nav>
      ${adminLinks}
      <div class="section-label">Analysis</div>
      <a href="user-dashboard.html"  class="${activePage==='dashboard'?'active':''}">📊 Dashboard</a>
      <a href="filter-location.html" class="${activePage==='location'?'active':''}">📍 Filter by Location</a>
      <a href="filter-type.html"     class="${activePage==='type'?'active':''}">🏷️ Filter by Type</a>
      <a href="trends.html"          class="${activePage==='trends'?'active':''}">📈 Crime Trends</a>
      <div class="section-label">Safety</div>
      <a href="alerts.html"          class="${activePage==='alerts'?'active':''}">🚨 Alerts & Safety</a>
      <div class="section-label">Reports</div>
      <a href="reports.html"         class="${activePage==='reports'?'active':''}">📄 Reports</a>
    </nav>
    <button class="logout-btn" onclick="logout()">⏻ Logout</button>
  `;
}

async function logout() {
  await fetch(`${API}/api/auth/logout`, { method: "POST", credentials: "include" });
  localStorage.clear();
  window.location.href = "../index.html";
}

function initPage(activePage) {
  const role    = localStorage.getItem("userRole") || "user";
  const sidebar = document.getElementById("sidebar");
  if (sidebar) sidebar.innerHTML = getSidebarHTML(activePage, role);
}

function riskBadge(level) {
  const map = {
    "Extreme Risk": ["extreme","🔴"],
    "High Risk":    ["high",   "🟠"],
    "Moderate Risk":["moderate","🟡"],
    "Safe":         ["safe",   "🟢"],
  };
  const [cls, icon] = map[level] || ["safe","🟢"];
  return `<span class="badge ${cls}">${icon} ${level}</span>`;
}

function scoreCircleClass(level) {
  return {"Safe":"safe","Moderate Risk":"moderate","High Risk":"high","Extreme Risk":"extreme"}[level]||"safe";
}
